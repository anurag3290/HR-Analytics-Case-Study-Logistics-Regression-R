# setting the current working directory
#setwd("C:/D/upgrad/HR Case study")

############################ HR Analytics ############################
### Business Understanding:

# Based on the employee information,
# the company has maintained a database containing employee general data, the employee's detailed
# information
# employee survey data, employee's reviews regaring current job
# manager survey data, managers's reviews regarding employees
# in and out data, employee in and out timing data

### Problem Statement
# Based on the data it has been observed that out of nearly 4000 employees, around 16% of its
# employees leave the company every year
# Due to this it cost the company in form of
# 1.to meet timelines ongoing project 
# 2.recruiting new talent
# 3.training

## AIM
# The aim is to automate the process of predicting 
# if a employee would leave or not and to find the factors affecting the attrition rate. 

# Install and Load the required packages
#install.packages("MASS")
#install.packages("e1071")
#install.packages("ggplot2")

# Load the libraries
library(MASS)
library(e1071)
library(ggplot2)
library(cowplot)
library(dplyr)
library(caTools)
library(car)
library(e1071)
library(caret)
library(ROCR)

## Loading files
emp_sur <- read.csv("employee_survey_data.csv", stringsAsFactors = FALSE)
gen_emp <- read.csv("general_data.csv", stringsAsFactors = FALSE)
mang_sur <- read.csv("manager_survey_data.csv", stringsAsFactors = FALSE)
in_time <- read.csv("in_time.csv", stringsAsFactors = FALSE)
out_time <- read.csv("out_time.csv", stringsAsFactors = FALSE)

# Removing the columns containing redundant data
# like in general_data we have EmployeeCount,Over18,StandardHours
# and in in_time and out_time we have columns containing all NAs
gen_emp <- gen_emp[ ,which(unlist(lapply(gen_emp, function(x)!all(length(unique(x)) == 1))))]
in_time <- in_time[ ,which(unlist(lapply(in_time, function(x)!all(length(unique(x)) == 1))))]
out_time <- out_time[ ,which(unlist(lapply(out_time, function(x)!all(length(unique(x)) == 1))))]


# Collate the data together in one single file(4410, confirming EmployeeID is key)
length(unique(tolower(emp_sur$EmployeeID)))
length(unique(tolower(gen_emp$EmployeeID))) 
length(unique(tolower(mang_sur$EmployeeID))) 

# Identical EmployeeID across these datasets
setdiff(emp_sur$EmployeeID,gen_emp$EmployeeID)
setdiff(mang_sur$EmployeeID,gen_emp$EmployeeID)

emp <- merge(emp_sur,gen_emp, by="EmployeeID", all = F)
emp <- merge(emp,mang_sur, by="EmployeeID", all = F)

################################################################

### Data Preparation & Exploratory Data Analysis
# Understanding the structure of the collated file
str(emp) #4410 obs. of 26 variables;


# Assuming the values in the first column of in_time and out_time correspond to Employee ID
# naming the first colum accordingly
colnames(in_time)[1] <- "EmployeeID"
colnames(out_time)[1] <- "EmployeeID"

# Identical EmployeeID across these datasets
setdiff(in_time$EmployeeID,gen_emp$EmployeeID)
setdiff(out_time$EmployeeID,gen_emp$EmployeeID)
# There are no mismatching employee ids

# converting the data in in_time and out_time to date format
in_time_df <- sapply(in_time[,-1], function(x) as.POSIXct(x, format = "%Y-%m-%d %H:%M:%S"))
out_time_df <- sapply(out_time[,-1], function(x) as.POSIXct(x, format = "%Y-%m-%d %H:%M:%S"))

# Calculating the leaves taken by each of the employee
# by calculating row wise sum of NAs in in_time and out_time sheet
# and also confirming that the values are same in both the sheets
leaves_in <- rowSums(is.na(out_time_df))
leaves_out <- rowSums(is.na(out_time_df))
setdiff(leaves_in, leaves_out)
leaves <- leaves_in


# Consiering all the days (including the leaves taken by the employee)
# Replacing all the NA values with 0 --> for calculating the average hours worked by an employee
in_time_df[is.na(in_time_df)] <- 0
out_time_df[is.na(out_time_df)] <- 0

hours_per_day <-  (out_time_df - in_time_df)/3600

avg_hours_per_emp <- rowMeans(hours_per_day)

# appending the leaves and averge_hrs column to the main data
emp <- cbind(emp,leaves,avg_hours_per_emp)

# removing the employee id column from the data set
emp <- emp[,-1]

# Checking for NAs in the final data set
unlist(lapply(emp, function(x) any(is.na(x))))
# EnvironmentSatisfaction, JobSatisfaction, WorkLifeBalance, NumCompaniesWorked, TotalWorkingYears


# Calculating the number of NAs in each of the columns
sum(is.na(emp$EnvironmentSatisfaction))
sum(is.na(emp$JobSatisfaction))
sum(is.na(emp$WorkLifeBalance))
sum(is.na(emp$NumCompaniesWorked))
sum(is.na(emp$TotalWorkingYears))

# filling up the NA values in EnvironmentSatisfaction, JobSatisfaction, WorkLifeBalance
# with median values
emp$EnvironmentSatisfaction[is.na(emp$EnvironmentSatisfaction)] <- median(emp$EnvironmentSatisfaction,na.rm = TRUE)
emp$JobSatisfaction[is.na(emp$JobSatisfaction)] <- median(emp$JobSatisfaction,na.rm = TRUE)
emp$WorkLifeBalance[is.na(emp$WorkLifeBalance)] <- median(emp$WorkLifeBalance,na.rm = TRUE)

# Checking for the NAs in the data
percenatage_of_NAs_in_data <- sum(is.na(emp))/nrow(emp) * 100
percenatage_of_NAs_in_data

# since the percentage of NAs left in data is very small 0.63%, so we can remove the rows containing
# NA values

# keeping a copy of data
emp_actual <- na.omit(emp)

emp <- emp_actual

#Plotting the graphs to visualize the attrition for categorical variables

bar_theme1<- theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5))

# plotting Business Travel and Department wise attrition in the company
plot_grid(ggplot(emp, aes(x=BusinessTravel,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1, 
          ggplot(emp, aes(x=Department,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          align = "h")  
# Non-Travelling jon has the lowest attrition rate whereas Frequent-travelling jobs have highest 
# The attrition rate among the HR department people is high

# plotting EducationField and Gender wise attrition in the company
plot_grid(ggplot(emp, aes(x=EducationField,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          ggplot(emp, aes(x=Gender,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          align = "h")   
# The highest attrition is among the people in the field of HR Studies
# Attrition rate is almost equal when it comes to gender - Male/Female

# plotting JobRole and Marital Status wise attrition in company
plot_grid(ggplot(emp, aes(x=JobRole,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          ggplot(emp, aes(x=MaritalStatus,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          align = "h")   
# Attrition rate is highest among people having Research Director as their job role
# Singles tend to leave the company more often

#Plotting the graphs to visualize the attrition for continuous variables

box_theme<- theme(axis.line=element_blank(),axis.title=element_blank(), 
                  axis.ticks=element_blank(), axis.text=element_blank())

plot_hist_box <- function(col1,x1){
  
  plot_grid(ggplot(emp, aes(col1))+ geom_histogram(binwidth = 1)+xlab(x1),
            ggplot(emp, aes(x="",y=col1))+ geom_boxplot(width=0.1)+coord_flip()+box_theme,
            align = "v",ncol = 1)
}


plot_hist_box_two <- function(col1,x1,col2,x2){
  
  plot_grid(ggplot(emp, aes(col1,))+ geom_histogram(binwidth = 1)+xlab(x1),
                   ggplot(emp, aes(x="",y=col1))+ geom_boxplot(width=0.1)+coord_flip()+box_theme,
            ggplot(emp, aes(col2))+ geom_histogram(binwidth = 1)+xlab(x2),
            ggplot(emp, aes(x="",y=col2))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
                   align = "v",ncol = 1)
}

plot_hist_box_two(emp$EnvironmentSatisfaction,"EnvironmentSatisfaction",emp$JobSatisfaction,"JobSatisfaction")
plot_hist_box_two(emp$WorkLifeBalance,"WorkLifeBalance",emp$Age,"Age")
plot_hist_box_two(emp$DistanceFromHome,"DistanceFromHome",emp$Education,"Education")
plot_hist_box(emp$JobLevel,"JobLevel",emp$MonthlyIncome,"MonthlyIncome")
plot_hist_box_two(emp$NumCompaniesWorked,"NumCompaniesWorked",emp$PercentSalaryHike,"PercentSalaryHike")
plot_hist_box_two(emp$StockOptionLevel,"StockOptionLevel",emp$TrainingTimesLastYear,"TrainingTimesLastYear")
plot_hist_box_two(emp$YearsAtCompany,"YearsAtCompany",emp$YearsSinceLastPromotion,"YearsSinceLastPromotion")
plot_hist_box_two(emp$YearsWithCurrManager,"YearsWithCurrManager",emp$JobInvolvement,"JobInvolvement")
plot_hist_box_two(emp$PerformanceRating,"PerformanceRating",emp$leaves,"leaves")
plot_hist_box_two(emp$avg_hours_per_emp,"avg_hours_per_emp")

# there are present outliers in the monthly income, average hour worked, the values are very high
# Scaling the data in that along with Age, DistanceFromHome, PercentSalaryHike, TotalWorkingYears,
# YearsAtCompany
emp$MonthlyIncome <- scale(emp$MonthlyIncome)
emp$Age <- scale(emp$Age)
emp$DistanceFromHome <- scale(emp$DistanceFromHome)
emp$PercentSalaryHike <- scale(emp$PercentSalaryHike)
emp$TotalWorkingYear <- scale(emp$TotalWorkingYears)
emp$YearsAtCompany <- scale(emp$YearsAtCompany)

# taking a look at the final formatted data
str(emp)

# Caluclating overall attrition rate
emp$Attrition <- ifelse(emp$Attrition=="Yes",1,0)
Attrition <- sum(emp$Attrition)/nrow(emp)


# creating the dummy variables for all the categorical data
col_names <- c("BusinessTravel", "Department", "EducationField", "Gender", "JobRole", "MaritalStatus")
categ_Df <- select(emp, BusinessTravel, Department, EducationField, Gender, JobRole, MaritalStatus)
attrition_fact<- data.frame(sapply(categ_Df, function(x) factor(x)))
dummies<- data.frame(sapply(attrition_fact,function(x) data.frame(model.matrix(~x-1,data =attrition_fact))[,-1]))

emp <- emp[ , !(names(emp) %in% col_names)]

# Final data set
emp <- cbind(emp,dummies)

# segregating the data into test and training data
set.seed(100)
indices = sample.split(emp$Attrition, SplitRatio = 0.7)
emp_train = emp[indices,]

emp_test = emp[!(indices),]

model_1 <- glm(Attrition ~ ., data = emp_train, family = "binomial")
summary(test_model)
# TotalWorkingYear seems to be non significant as the coefficients and the p-value is NA

# running the stepAIC function on model_1
model_2 <- stepAIC(model_1, direction="both")
summary(model_2)
sort(vif(model_2))

# removing YearsAtCompany based on the vif and p-value
model_3 <- glm(Attrition ~ EnvironmentSatisfaction + JobSatisfaction + WorkLifeBalance + 
                 Age + MonthlyIncome + NumCompaniesWorked + StockOptionLevel + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + avg_hours_per_emp + 
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 EducationField.xLife.Sciences + EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Representative + MaritalStatus.xMarried + 
                 MaritalStatus.xSingle, data=emp_test)
summary(model_3)
sort(vif(model_3))

# removing EducationField.xLife.Sciences based on vif value and p-value
model_4 <- glm(Attrition ~ EnvironmentSatisfaction + JobSatisfaction + WorkLifeBalance + 
                 Age + MonthlyIncome + NumCompaniesWorked + StockOptionLevel + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + avg_hours_per_emp + 
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Representative + MaritalStatus.xMarried + 
                 MaritalStatus.xSingle, data=emp_test)
summary(model_4)
sort(vif(model_4))

# removing TotalWorkingYears based on high p-value
model_5 <- glm(Attrition ~ EnvironmentSatisfaction + JobSatisfaction + WorkLifeBalance + 
                 Age + MonthlyIncome + NumCompaniesWorked + StockOptionLevel + 
                 TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + avg_hours_per_emp + 
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Representative + MaritalStatus.xMarried + 
                 MaritalStatus.xSingle, data=emp_test)
summary(model_5)
sort(vif(model_5))


# Need to revisit here
# removing BusinessTravel.xTravel_Rarely based on p-value and vif
model_6 <- glm(Attrition ~ EnvironmentSatisfaction + JobSatisfaction + WorkLifeBalance + 
                 Age + MonthlyIncome + NumCompaniesWorked + StockOptionLevel + 
                 TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + avg_hours_per_emp + 
                 BusinessTravel.xTravel_Frequently + 
                 EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Representative + MaritalStatus.xMarried + 
                 MaritalStatus.xSingle, data=emp_test)
summary(model_6)
sort(vif(model_6))

# removing MonthlyIncome based on very high p-value
model_7 <- glm(Attrition ~ EnvironmentSatisfaction + JobSatisfaction + WorkLifeBalance + 
                 Age + NumCompaniesWorked + StockOptionLevel + 
                 TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + avg_hours_per_emp + 
                 BusinessTravel.xTravel_Frequently + 
                 EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Representative + MaritalStatus.xMarried + 
                 MaritalStatus.xSingle, data=emp_test)
summary(model_7)
sort(vif(model_7))


# removing JobRole.xResearch.Director based on very high p-value
model_8 <- glm(Attrition ~ EnvironmentSatisfaction + JobSatisfaction + WorkLifeBalance + 
                 Age + NumCompaniesWorked + StockOptionLevel + 
                 TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + avg_hours_per_emp + 
                 BusinessTravel.xTravel_Frequently + 
                 EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobRole.xManufacturing.Director + 
                 JobRole.xSales.Representative + MaritalStatus.xMarried + 
                 MaritalStatus.xSingle, data=emp_test)
summary(model_8)
sort(vif(model_8))


# removing EducationField.xTechnical.Degree based on very high p-value
model_9 <- glm(Attrition ~ EnvironmentSatisfaction + JobSatisfaction + WorkLifeBalance + 
                 Age + NumCompaniesWorked + StockOptionLevel + 
                 TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + avg_hours_per_emp + 
                 BusinessTravel.xTravel_Frequently + 
                 EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + 
                 JobRole.xManufacturing.Director + 
                 JobRole.xSales.Representative + MaritalStatus.xMarried + 
                 MaritalStatus.xSingle, data=emp_test)
summary(model_9)
sort(vif(model_9))



# removing EducationField.xMarketing based on very high p-value
model_10 <- glm(Attrition ~ EnvironmentSatisfaction + JobSatisfaction + WorkLifeBalance + 
                 Age + NumCompaniesWorked + StockOptionLevel + 
                 TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + avg_hours_per_emp + 
                 BusinessTravel.xTravel_Frequently + 
                 EducationField.xMedical + EducationField.xOther + 
                 JobRole.xManufacturing.Director + 
                 JobRole.xSales.Representative + MaritalStatus.xMarried + 
                 MaritalStatus.xSingle, data=emp_test)
summary(model_10)
sort(vif(model_10))


# removing JobRole.xSales.Representative based on very high p-value
model_11 <- glm(Attrition ~ EnvironmentSatisfaction + JobSatisfaction + WorkLifeBalance + 
                  Age + NumCompaniesWorked + StockOptionLevel + 
                  TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + avg_hours_per_emp + 
                  BusinessTravel.xTravel_Frequently + 
                  EducationField.xMedical + EducationField.xOther + 
                  JobRole.xManufacturing.Director + 
                  MaritalStatus.xMarried + 
                  MaritalStatus.xSingle, data=emp_test)
summary(model_11)
sort(vif(model_11))

# removing EducationField.xOther based on very high p-value
model_12 <- glm(Attrition ~ EnvironmentSatisfaction + JobSatisfaction + WorkLifeBalance + 
                  Age + NumCompaniesWorked + StockOptionLevel + 
                  TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + avg_hours_per_emp + 
                  BusinessTravel.xTravel_Frequently + 
                  EducationField.xMedical + 
                  JobRole.xManufacturing.Director + 
                  MaritalStatus.xMarried + 
                  MaritalStatus.xSingle, data=emp_test)
summary(model_12)
sort(vif(model_12))


# removing EducationField.xMedical based on very high p-value
model_13 <- glm(Attrition ~ EnvironmentSatisfaction + JobSatisfaction + WorkLifeBalance + 
                  Age + NumCompaniesWorked + StockOptionLevel + 
                  TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + avg_hours_per_emp + 
                  BusinessTravel.xTravel_Frequently + 
                  JobRole.xManufacturing.Director + 
                  MaritalStatus.xMarried + 
                  MaritalStatus.xSingle, data=emp_test)
summary(model_13)
sort(vif(model_13))


# removing StockOptionLevel based on very high p-value
model_14 <- glm(Attrition ~ EnvironmentSatisfaction + JobSatisfaction + WorkLifeBalance + 
                  Age + NumCompaniesWorked + 
                  TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + avg_hours_per_emp + 
                  BusinessTravel.xTravel_Frequently + 
                  JobRole.xManufacturing.Director + 
                  MaritalStatus.xMarried + 
                  MaritalStatus.xSingle, data=emp_test)
summary(model_14)
sort(vif(model_14))


# removing MaritalStatus.xMarried based on very high p-value
model_15 <- glm(Attrition ~ EnvironmentSatisfaction + JobSatisfaction + WorkLifeBalance + 
                  Age + NumCompaniesWorked + 
                  TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + avg_hours_per_emp + 
                  BusinessTravel.xTravel_Frequently + 
                  JobRole.xManufacturing.Director + 
                  MaritalStatus.xSingle, data=emp_test)
summary(model_15)
sort(vif(model_15))



# removing JobRole.xManufacturing.Director based on very high p-value
model_16 <- glm(Attrition ~ EnvironmentSatisfaction + JobSatisfaction + WorkLifeBalance + 
                  Age + NumCompaniesWorked + 
                  TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + avg_hours_per_emp + 
                  BusinessTravel.xTravel_Frequently + 
                  MaritalStatus.xSingle, data=emp_test)
summary(model_16)
sort(vif(model_16))



### Model Evaluation
### Test Data ####
#predicted probabilities of attrition for test data
test_pred = predict(model_16, type = "response", newdata = emp_test[,-5])

# Let's see the summary 
summary(test_pred)

emp_test$pred <- test_pred
View(emp_test)


# Let's use the probability cutoff of 35%.
test_pred_attr <- factor(ifelse(test_pred >= 0.35, "Yes", "No"))
test_actual_attr_yn <- factor(ifelse(emp_test$Attrition==1,"Yes","No"))

# Creating a confusion matrix to find the accuracy, sensitivity and specficity values
test_conf <- confusionMatrix(test_pred_attr, test_actual_attr_yn, positive = "Yes")
test_conf
# but the sensitivity value is very low, so let try to find an optimal value

# Let's find out the optimal probalility cutoff 

perform_fn <- function(cutoff) 
{
  predicted_attr <- factor(ifelse(test_pred >= cutoff, "Yes", "No"))
  conf <- confusionMatrix(predicted_attr, test_actual_attr_yn, positive = "Yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

# initiallizing a matrix of 100 X 3.
s = seq(.02,.80,length=100)
OUT = matrix(0,100,3)

for(i in 1:100){
  OUT[i,] = perform_fn(s[i])
} 


plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))


cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.01)]
cutoff

# the optimal cutoff value is .2169 where all the three sensitivity, specificity and accuracy gets balanced
# but to make the system a bit more accurate we are choosing a value of 0.25

test_cutoff_attr_yn <- factor(ifelse(test_pred >= 0.25, "Yes", "No"))
# Creating a confusion matrix to find the accuracy, sensitivity and specficity values
final_conf <- confusionMatrix(test_cutoff_attr_yn, test_actual_attr_yn, positive = "Yes")
final_conf

acc <- final_conf$overall[1]
sens <- final_conf$byClass[1]
spec <- final_conf$byClass[2]



### KS -statistic - Test Data ######

test_cutoff_attr <- ifelse(test_cutoff_attr_yn=="Yes",1,0)
test_actual_attr <- ifelse(test_actual_attr_yn=="Yes",1,0)

#on testing  data
pred_object_test<- prediction(test_cutoff_attr, test_actual_attr)

performance_measures_test<- performance(pred_object_test, "tpr", "fpr")

ks_table_test <- attr(performance_measures_test, "y.values")[[1]] - (attr(performance_measures_test, "x.values")[[1]])

max(ks_table_test)


####################################################################
# Lift & Gain Chart 

lift <- function(labels , predicted_prob,groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups))) 
  return(gaintable)
}

attr_decile = lift(test_actual_attr, test_pred, groups = 10)

